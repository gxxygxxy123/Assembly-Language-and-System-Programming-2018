// makearray.c

void makeArray( ) 
{
	char myString[30];
	int i;

	for( i = 0; i < 30; i++ )
		myString[i] = (char)i;

}


void main()
{

	makeArray();


}